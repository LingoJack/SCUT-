package lexer;

public class STR extends Token
{
    public final String value;

    public STR(String value)
    {
        super(Tag.STR);
        this.value = value;
    }

    public String toString()
    {
        return value;
    }
}
