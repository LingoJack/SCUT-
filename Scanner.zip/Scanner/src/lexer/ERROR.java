package lexer;

public class ERROR extends Token
{
    public final String error;

    public ERROR(String v)
    {
        super(Tag.ERROR);
        error=v;
    }

    @Override
    public String toString()
    {
        return error;
    }
}
