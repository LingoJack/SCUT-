package lexer;

public class DOU extends Token
{
    public final String value;
    public DOU(String v)
    {
        super(Tag.DOUBLE);
        value = v;
    }

    @Override
    public String toString()
    {
        return value;
    }
}
