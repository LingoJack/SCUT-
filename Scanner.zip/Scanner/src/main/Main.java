package main;

import lexer.*;

import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        // ����һ���ʷ�������
        Lexer lexer = new Lexer();
        char c;
        do
        {
            // ���ôʷ���������scan�������ڴ�ѭ�����н����ж�
            Token token = lexer.scan();
            switch(token.tag)
            {
                case Tag.NUM:
                case Tag.REAL:
                    System.out.println("(NUM , " + token.toString() + ")");
                    break;
                case Tag.DOUBLE:
                    System.out.println("(DOUBLE ,"+ token.toString() + ")");
                    break;
                case Tag.ID:
                    System.out.println("(ID , " + token.toString() + ")");
                    break;
                case Tag.AND:
                case Tag.BASIC:
                case Tag.BREAK:
                case Tag.DO:
                case Tag.ELSE:
                case Tag.IF:
                case Tag.TRUE:
                case Tag.WHILE:
                case Tag.FALSE:
                case Tag.CLASS:
                case Tag.FOR:
                case Tag.STATIC:
                case Tag.VOID:
                case Tag.NEW:
                case Tag.PRINT:
                case Tag.READINTEGER:
                case Tag.RETURN:
                case Tag.INT:
                case Tag.MAIN:
                case Tag.STRING:
                case Tag.NEWARRAY:
                case Tag.READLINE:
                case Tag.NULL:
                case Tag.THIS:
                case Tag.EXTENDS:
                case Tag.BOOL:
                    System.out.println("(KEY , " + token.toString() + ")");
                    break;
                case Tag.STR:
                    System.out.println("(STR , " + token.toString() + ")");
                    break;
                case Tag.COMMENT:
                    break;
                case Tag.ERROR:
                    System.out.println("(ERROR : " + token.toString() + ")");
                    break;
                default:
                    System.out.println("(SYM , " + token.toString() + ")");
                    break;
            }

        } while (lexer.getPeek() != '\n');
    }
}
